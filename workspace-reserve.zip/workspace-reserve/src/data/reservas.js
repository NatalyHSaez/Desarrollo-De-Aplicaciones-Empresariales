const reservas = [
  // Este array puede estar vacío al inicio
];

export default reservas;
